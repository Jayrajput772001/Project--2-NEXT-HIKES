
import tkinter as tk
from tkinter import ttk, messagebox
import math
import ast
import operator

# ============================================================
# SAFE MATHEMATICAL EXPRESSION EVALUATOR
# ============================================================

BINARY_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv
}

UNARY_OPERATORS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg
}


def safe_factorial(value):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("Factorial requires a whole number.")
    if value < 0 or value > 170:
        raise ValueError("Factorial must be between 0 and 170.")
    return math.factorial(value)


def safe_calculate(expression, variables=None, functions=None):
    variables = variables or {}
    functions = functions or {}

    if not isinstance(expression, str) or len(expression) > 300:
        raise ValueError("Invalid or excessively long expression.")

    names = {"pi": math.pi, "e": math.e, **variables}

    allowed_nodes = (
        ast.Expression, ast.Constant, ast.BinOp,
        ast.UnaryOp, ast.Call, ast.Name, ast.Load,
        ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow,
        ast.Mod, ast.FloorDiv, ast.UAdd, ast.USub
    )

    tree = ast.parse(expression, mode="eval")

    if sum(1 for _ in ast.walk(tree)) > 100:
        raise ValueError("Expression is too complicated.")

    for node in ast.walk(tree):
        if not isinstance(node, allowed_nodes):
            raise ValueError("Unsupported mathematical operation.")

        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or not isinstance(
                node.value, (int, float)
            ):
                raise ValueError("Only numerical values are allowed.")

        if isinstance(node, ast.Name):
            if node.id not in names and node.id not in functions:
                raise ValueError(f"Unknown name: {node.id}")

        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name):
                raise ValueError("Invalid function.")
            if node.func.id not in functions or node.keywords:
                raise ValueError("Function not allowed.")

    def evaluate(node):
        if isinstance(node, ast.Expression):
            return evaluate(node.body)

        if isinstance(node, ast.Constant):
            return node.value

        if isinstance(node, ast.Name):
            return names[node.id]

        if isinstance(node, ast.BinOp):
            left = evaluate(node.left)
            right = evaluate(node.right)

            if isinstance(node.op, ast.Pow):
                if abs(right) > 1000:
                    raise ValueError("Exponent is too large.")

            result = BINARY_OPERATORS[type(node.op)](left, right)

            if isinstance(result, (int, float)) and abs(result) > 1e300:
                raise ValueError("Result is too large.")

            return result

        if isinstance(node, ast.UnaryOp):
            return UNARY_OPERATORS[type(node.op)](
                evaluate(node.operand)
            )

        if isinstance(node, ast.Call):
            args = [evaluate(arg) for arg in node.args]
            return functions[node.func.id](*args)

        raise ValueError("Invalid expression.")

    return evaluate(tree)


# ============================================================
# MAIN APPLICATION
# ============================================================

class AdvancedCalculator:

    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Scientific Calculator")
        self.root.geometry("1100x760")
        self.root.minsize(900, 650)

        self.history = []
        self.memory = 0
        self.angle_mode = "DEG"

        self.theme_name = tk.StringVar(value="Midnight Blue")

        self.themes = {
            "Midnight Blue": {
                "bg": "#101827", "panel": "#1c293b",
                "fg": "#f1f5f9", "accent": "#38bdf8",
                "button": "#29394f", "entry": "#0b1422"
            },
            "Midnight Purple": {
                "bg": "#171326", "panel": "#28213d",
                "fg": "#f5f0ff", "accent": "#c084fc",
                "button": "#3b3155", "entry": "#100c1c"
            },
            "Ocean Blue": {
                "bg": "#082f49", "panel": "#164e63",
                "fg": "#ecfeff", "accent": "#22d3ee",
                "button": "#155e75", "entry": "#083344"
            },
            "Emerald Green": {
                "bg": "#102a23", "panel": "#1c4034",
                "fg": "#ecfdf5", "accent": "#34d399",
                "button": "#285443", "entry": "#092018"
            },
            "Light": {
                "bg": "#edf2f7", "panel": "#ffffff",
                "fg": "#172033", "accent": "#2563eb",
                "button": "#dbe5f1", "entry": "#ffffff"
            }
        }

        self.style = ttk.Style()
        self.style.theme_use("clam")

        self.create_interface()
        self.apply_theme()

    # ========================================================
    # INTERFACE
    # ========================================================

    def create_interface(self):
        header = tk.Frame(self.root)
        header.pack(fill="x", padx=15, pady=12)

        self.heading = tk.Label(
            header,
            text="ADVANCED SCIENTIFIC CALCULATOR",
            font=("Arial", 19, "bold")
        )
        self.heading.pack(side="left")

        self.history_button = tk.Button(
            header, text="HISTORY",
            command=self.show_history,
            padx=12, pady=5
        )
        self.history_button.pack(side="right", padx=8)

        self.theme_menu = ttk.Combobox(
            header,
            textvariable=self.theme_name,
            values=list(self.themes.keys()),
            state="readonly",
            width=18
        )
        self.theme_menu.pack(side="right", padx=5)
        self.theme_menu.bind(
            "<<ComboboxSelected>>",
            lambda event: self.apply_theme()
        )

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=15, pady=10)

        self.calculator_tab = tk.Frame(self.notebook)
        self.converter_tab = tk.Frame(self.notebook)
        self.graph_tab = tk.Frame(self.notebook)
        self.bmi_tab = tk.Frame(self.notebook)
        self.gst_tab = tk.Frame(self.notebook)

        self.notebook.add(self.calculator_tab, text="Scientific Calculator")
        self.notebook.add(self.converter_tab, text="Unit Converter")
        self.notebook.add(self.graph_tab, text="2D Graph")
        self.notebook.add(self.bmi_tab, text="BMI Calculator")
        self.notebook.add(self.gst_tab, text="GST Calculator")

        self.create_calculator()
        self.create_converter()
        self.create_graph()
        self.create_bmi()
        self.create_gst()

    # ========================================================
    # SCIENTIFIC CALCULATOR
    # ========================================================

    def create_calculator(self):
        frame = self.calculator_tab

        self.expression = tk.StringVar()

        self.display = tk.Entry(
            frame, textvariable=self.expression,
            font=("Arial", 25), justify="right", bd=0
        )
        self.display.pack(fill="x", padx=15, pady=15, ipady=15)

        controls = tk.Frame(frame)
        controls.pack(fill="both", expand=True, padx=10, pady=5)

        buttons = [
            ["sin", "cos", "tan", "log", "ln", "sqrt"],
            ["asin", "acos", "atan", "π", "e", "x²"],
            ["7", "8", "9", "/", "(", ")"],
            ["4", "5", "6", "*", "%", "x!"],
            ["1", "2", "3", "-", "1/x", "C"],
            ["0", ".", "±", "+", "⌫", "="],
            ["MC", "MR", "M+", "M-", "DEG/RAD", "exp"]
        ]

        for r, row in enumerate(buttons):
            for c, label in enumerate(row):
                button = tk.Button(
                    controls,
                    text=label,
                    font=("Arial", 12, "bold"),
                    command=lambda value=label: self.press(value)
                )
                button.grid(
                    row=r, column=c, sticky="nsew",
                    padx=4, pady=4, ipady=12
                )

        for i in range(6):
            controls.columnconfigure(i, weight=1)

        for i in range(len(buttons)):
            controls.rowconfigure(i, weight=1)

        self.display.bind("<Return>", lambda event: self.calculate())
        self.display.bind("<KP_Enter>", lambda event: self.calculate())
        self.display.bind("<Escape>", lambda event: self.clear())
        self.display.bind("<BackSpace>", lambda event: self.backspace())

    def get_functions(self):
        if self.angle_mode == "DEG":
            sin = lambda x: math.sin(math.radians(x))
            cos = lambda x: math.cos(math.radians(x))
            tan = lambda x: math.tan(math.radians(x))
            asin = lambda x: math.degrees(math.asin(x))
            acos = lambda x: math.degrees(math.acos(x))
            atan = lambda x: math.degrees(math.atan(x))
        else:
            sin, cos, tan = math.sin, math.cos, math.tan
            asin, acos, atan = math.asin, math.acos, math.atan

        return {
            "sin": sin, "cos": cos, "tan": tan,
            "asin": asin, "acos": acos, "atan": atan,
            "log": math.log10, "ln": math.log,
            "sqrt": math.sqrt, "factorial": safe_factorial,
            "exp": math.exp, "abs": abs
        }

    def press(self, key):
        current = self.expression.get()

        if key == "=":
            self.calculate()
        elif key == "C":
            self.clear()
        elif key == "⌫":
            self.backspace()
        elif key == "π":
            self.expression.set(current + "pi")
        elif key == "x²":
            self.expression.set(current + "**2")
        elif key == "x!":
            self.expression.set(current + "!")
            messagebox.showinfo(
                "Factorial",
                "Use factorial(number) to calculate factorial.\n"
                "Example: factorial(5)"
            )
        elif key == "1/x":
            self.expression.set("1/(" + current + ")")
        elif key == "±":
            if current:
                self.expression.set("-(" + current + ")")
        elif key == "DEG/RAD":
            self.angle_mode = "RAD" if self.angle_mode == "DEG" else "DEG"
            messagebox.showinfo("Angle mode", "Angle mode: " + self.angle_mode)
        elif key == "MC":
            self.memory = 0
        elif key == "MR":
            self.expression.set(current + str(self.memory))
        elif key == "M+":
            self.memory += float(self.calculate_value())
        elif key == "M-":
            self.memory -= float(self.calculate_value())
        else:
            self.expression.set(current + key)

    def clear(self):
        self.expression.set("")

    def backspace(self):
        self.expression.set(self.expression.get()[:-1])

    def calculate_value(self):
        try:
            return safe_calculate(
                self.expression.get(),
                functions=self.get_functions()
            )
        except Exception as error:
            raise ValueError(str(error))

    def calculate(self):
        expression = self.expression.get()

        try:
            result = self.calculate_value()

            if not isinstance(result, (int, float)) or not math.isfinite(result):
                raise ValueError("Result is not a valid finite number.")

            formatted = f"{result:.12g}"
            self.history.append(expression + " = " + formatted)
            self.expression.set(formatted)

        except Exception as error:
            messagebox.showerror("Calculation Error", str(error))

    # ========================================================
    # HISTORY POPUP
    # ========================================================

    def show_history(self):
        window = tk.Toplevel(self.root)
        window.title("Calculation History")
        window.geometry("500x450")

        tk.Label(
            window, text="CALCULATION HISTORY",
            font=("Arial", 16, "bold")
        ).pack(pady=10)

        listbox = tk.Listbox(window, font=("Arial", 11))
        listbox.pack(fill="both", expand=True, padx=15, pady=10)

        for item in self.history:
            listbox.insert(tk.END, item)

        def clear_history():
            self.history.clear()
            listbox.delete(0, tk.END)

        tk.Button(
            window, text="Clear History",
            command=clear_history
        ).pack(pady=10)

    # ========================================================
    # UNIT CONVERTER
    # ========================================================

    def create_converter(self):
        frame = self.converter_tab

        tk.Label(
            frame, text="UNIT CONVERTER",
            font=("Arial", 18, "bold")
        ).pack(pady=15)

        self.unit_category = tk.StringVar(value="Length")
        self.unit_from = tk.StringVar(value="Meter")
        self.unit_to = tk.StringVar(value="Kilometer")
        self.unit_value = tk.StringVar()

        tk.Label(frame, text="Category").pack(pady=5)

        category = ttk.Combobox(
            frame, textvariable=self.unit_category,
            values=["Length", "Weight", "Temperature", "Volume"],
            state="readonly"
        )
        category.pack()

        category.bind(
            "<<ComboboxSelected>>",
            lambda event: self.update_unit_options()
        )

        tk.Label(frame, text="Enter value").pack(pady=5)
        tk.Entry(
            frame, textvariable=self.unit_value,
            font=("Arial", 14)
        ).pack()

        tk.Label(frame, text="From").pack(pady=5)
        self.from_menu = ttk.Combobox(
            frame, textvariable=self.unit_from, state="readonly"
        )
        self.from_menu.pack()

        tk.Label(frame, text="To").pack(pady=5)
        self.to_menu = ttk.Combobox(
            frame, textvariable=self.unit_to, state="readonly"
        )
        self.to_menu.pack()

        tk.Button(
            frame, text="CONVERT",
            command=self.convert_units,
            font=("Arial", 12, "bold")
        ).pack(pady=15)

        self.unit_result = tk.Label(
            frame, text="Result: ",
            font=("Arial", 16, "bold")
        )
        self.unit_result.pack(pady=10)

        self.update_unit_options()

    def update_unit_options(self):
        units = {
            "Length": ["Meter", "Kilometer", "Centimeter", "Millimeter", "Mile", "Foot", "Inch"],
            "Weight": ["Kilogram", "Gram", "Milligram", "Pound"],
            "Temperature": ["Celsius", "Fahrenheit", "Kelvin"],
            "Volume": ["Liter", "Milliliter", "Cubic Meter", "Gallon"]
        }

        selected = units[self.unit_category.get()]
        self.from_menu["values"] = selected
        self.to_menu["values"] = selected
        self.unit_from.set(selected[0])
        self.unit_to.set(selected[1])

    def convert_units(self):
        try:
            value = float(self.unit_value.get())
            category = self.unit_category.get()
            source = self.unit_from.get()
            target = self.unit_to.get()

            if category == "Temperature":
                if source == "Celsius":
                    celsius = value
                elif source == "Fahrenheit":
                    celsius = (value - 32) * 5 / 9
                else:
                    celsius = value - 273.15

                if target == "Celsius":
                    result = celsius
                elif target == "Fahrenheit":
                    result = celsius * 9 / 5 + 32
                else:
                    result = celsius + 273.15

            else:
                factors = {
                    "Length": {
                        "Meter": 1, "Kilometer": 1000,
                        "Centimeter": 0.01, "Millimeter": 0.001,
                        "Mile": 1609.344, "Foot": 0.3048,
                        "Inch": 0.0254
                    },
                    "Weight": {
                        "Kilogram": 1, "Gram": 0.001,
                        "Milligram": 0.000001, "Pound": 0.45359237
                    },
                    "Volume": {
                        "Liter": 1, "Milliliter": 0.001,
                        "Cubic Meter": 1000, "Gallon": 3.785411784
                    }
                }

                result = value * factors[category][source] / factors[category][target]

            self.unit_result.config(text=f"Result: {result:.8g} {target}")

        except Exception as error:
            messagebox.showerror("Conversion Error", str(error))

    # ========================================================
    # 2D GRAPH PLOTTER - TKINTER CANVAS, NO EXTRA LIBRARIES
    # ========================================================

    def create_graph(self):
        frame = self.graph_tab

        tk.Label(
            frame, text="2D GRAPH PLOTTER",
            font=("Arial", 18, "bold")
        ).pack(pady=10)

        controls = tk.Frame(frame)
        controls.pack(pady=10)

        self.graph_expression = tk.StringVar(value="sin(x)")
        self.graph_min = tk.StringVar(value="-10")
        self.graph_max = tk.StringVar(value="10")

        tk.Label(controls, text="Function:").grid(row=0, column=0, padx=5)
        tk.Entry(
            controls, textvariable=self.graph_expression, width=20
        ).grid(row=0, column=1, padx=5)

        tk.Label(controls, text="X minimum:").grid(row=0, column=2, padx=5)
        tk.Entry(
            controls, textvariable=self.graph_min, width=8
        ).grid(row=0, column=3, padx=5)

        tk.Label(controls, text="X maximum:").grid(row=0, column=4, padx=5)
        tk.Entry(
            controls, textvariable=self.graph_max, width=8
        ).grid(row=0, column=5, padx=5)

        tk.Button(
            controls, text="PLOT GRAPH",
            command=self.plot_graph
        ).grid(row=0, column=6, padx=8)

        self.graph_canvas = tk.Canvas(
            frame, height=450, bg="white",
            highlightthickness=1
        )
        self.graph_canvas.pack(
            fill="both", expand=True, padx=15, pady=10
        )

        self.graph_canvas.bind(
            "<Configure>",
            lambda event: self.plot_graph()
        )

        self.root.after(300, self.plot_graph)

    def plot_graph(self):
        if not hasattr(self, "graph_canvas"):
            return

        canvas = self.graph_canvas
        canvas.delete("all")

        width = canvas.winfo_width()
        height = canvas.winfo_height()

        if width < 100 or height < 100:
            return

        try:
            xmin = float(self.graph_min.get())
            xmax = float(self.graph_max.get())

            if not math.isfinite(xmin) or not math.isfinite(xmax) or xmin >= xmax:
                raise ValueError("X minimum must be smaller than X maximum.")

            expression = self.graph_expression.get().strip()

            if not expression or len(expression) > 200:
                raise ValueError("Enter a valid graph function.")

            graph_functions = {
                "sin": math.sin, "cos": math.cos,
                "tan": math.tan, "sqrt": math.sqrt,
                "log": math.log10, "ln": math.log,
                "abs": abs, "exp": math.exp
            }

            values = []
            for i in range(501):
                x = xmin + (xmax - xmin) * i / 500

                try:
                    y = safe_calculate(
                        expression,
                        variables={"x": x},
                        functions=graph_functions
                    )
                    if not isinstance(y, (int, float)) or not math.isfinite(y):
                        y = None
                    elif abs(y) > 1e6:
                        y = None
                except (ValueError, ArithmeticError, OverflowError):
                    y = None

                values.append((x, y))

            valid_y = [y for _, y in values if y is not None]
            if not valid_y:
                raise ValueError("No valid points to plot in this range.")

            ymin = min(valid_y)
            ymax = max(valid_y)

            if ymin == ymax:
                ymin -= 1
                ymax += 1

            padding = (ymax - ymin) * 0.1
            ymin -= padding
            ymax += padding

            def px(x):
                return 50 + (x - xmin) / (xmax - xmin) * (width - 70)

            def py(y):
                return height - 40 - (y - ymin) / (ymax - ymin) * (height - 70)

            # Grid
            for i in range(11):
                gx = 50 + i * (width - 70) / 10
                gy = 30 + i * (height - 70) / 10
                canvas.create_line(gx, 30, gx, height - 40, fill="#e5e7eb")
                canvas.create_line(50, gy, width - 20, gy, fill="#e5e7eb")

            # Axes
            if xmin <= 0 <= xmax:
                x_axis = px(0)
                canvas.create_line(
                    x_axis, 30, x_axis, height - 40,
                    fill="#64748b", width=2
                )

            if ymin <= 0 <= ymax:
                y_axis = py(0)
                canvas.create_line(
                    50, y_axis, width - 20, y_axis,
                    fill="#64748b", width=2
                )

            # Graph line
            previous = None
            for x, y in values:
                if y is None:
                    previous = None
                    continue

                point = (px(x), py(y))

                if previous is not None:
                    if abs(point[1] - previous[1]) < height * 2:
                        canvas.create_line(
                            previous[0], previous[1],
                            point[0], point[1],
                            fill="#2563eb", width=2
                        )

                previous = point

            canvas.create_text(
                width // 2, 15,
                text="y = " + expression,
                fill="#111827",
                font=("Arial", 12, "bold")
            )

            canvas.create_text(
                width - 35, height - 15,
                text="X",
                fill="#111827"
            )

            canvas.create_text(
                20, 20, text="Y",
                fill="#111827"
            )

        except Exception as error:
            canvas.create_text(
                width // 2, height // 2,
                text=str(error),
                fill="red",
                font=("Arial", 12)
            )

    # ========================================================
    # BMI CALCULATOR
    # ========================================================

    def create_bmi(self):
        frame = self.bmi_tab

        tk.Label(
            frame, text="BMI CALCULATOR",
            font=("Arial", 18, "bold")
        ).pack(pady=20)

        self.bmi_weight = tk.StringVar()
        self.bmi_height = tk.StringVar()

        tk.Label(frame, text="Weight (kg)").pack(pady=5)
        tk.Entry(
            frame, textvariable=self.bmi_weight,
            font=("Arial", 14)
        ).pack()

        tk.Label(frame, text="Height (cm)").pack(pady=5)
        tk.Entry(
            frame, textvariable=self.bmi_height,
            font=("Arial", 14)
        ).pack()

        tk.Button(
            frame, text="CALCULATE BMI",
            command=self.calculate_bmi,
            font=("Arial", 12, "bold")
        ).pack(pady=20)

        self.bmi_result = tk.Label(
            frame, text="Your BMI: ",
            font=("Arial", 17, "bold")
        )
        self.bmi_result.pack(pady=10)

    def calculate_bmi(self):
        try:
            weight = float(self.bmi_weight.get())
            height = float(self.bmi_height.get()) / 100

            if not math.isfinite(weight) or not math.isfinite(height):
                raise ValueError("Enter valid numbers.")

            if weight <= 0 or height <= 0:
                raise ValueError("Weight and height must be positive.")

            bmi = weight / (height ** 2)

            if bmi < 18.5:
                category = "Underweight"
            elif bmi < 25:
                category = "Normal weight"
            elif bmi < 30:
                category = "Overweight"
            else:
                category = "Obese"

            self.bmi_result.config(
                text=f"Your BMI: {bmi:.2f}\nCategory: {category}"
            )

        except Exception as error:
            messagebox.showerror("BMI Error", str(error))

    # ========================================================
    # GST CALCULATOR
    # ========================================================

    def create_gst(self):
        frame = self.gst_tab

        tk.Label(
            frame, text="GST CALCULATOR",
            font=("Arial", 18, "bold")
        ).pack(pady=15)

        self.gst_amount = tk.StringVar()
        self.gst_rate = tk.StringVar(value="18")
        self.gst_type = tk.StringVar(value="Exclusive")
        self.gst_mode = tk.StringVar(value="CGST + SGST")

        tk.Label(frame, text="Enter Amount (₹)").pack(pady=5)
        tk.Entry(
            frame, textvariable=self.gst_amount,
            font=("Arial", 14)
        ).pack()

        tk.Label(frame, text="GST Rate").pack(pady=5)
        ttk.Combobox(
            frame, textvariable=self.gst_rate,
            values=["5", "12", "18", "28"],
            state="readonly"
        ).pack()

        tk.Label(frame, text="Calculation Type").pack(pady=5)
        ttk.Combobox(
            frame, textvariable=self.gst_type,
            values=["Exclusive", "Inclusive"],
            state="readonly"
        ).pack()

        tk.Label(frame, text="GST Mode").pack(pady=5)
        ttk.Combobox(
            frame, textvariable=self.gst_mode,
            values=["CGST + SGST", "IGST"],
            state="readonly"
        ).pack()

        tk.Button(
            frame, text="CALCULATE GST",
            command=self.calculate_gst,
            font=("Arial", 12, "bold")
        ).pack(pady=15)

        self.gst_result = tk.Label(
            frame, text="GST Result",
            font=("Arial", 14, "bold"),
            justify="left"
        )
        self.gst_result.pack(pady=10)

    def calculate_gst(self):
        try:
            amount = float(self.gst_amount.get())
            rate = float(self.gst_rate.get())

            if not math.isfinite(amount) or amount < 0:
                raise ValueError("Enter a valid non-negative amount.")

            if self.gst_type.get() == "Exclusive":
                taxable = amount
                gst = taxable * rate / 100
                total = taxable + gst
            else:
                total = amount
                taxable = total / (1 + rate / 100)
                gst = total - taxable

            if self.gst_mode.get() == "CGST + SGST":
                cgst = gst / 2
                sgst = gst / 2
                breakdown = (
                    f"CGST ({rate/2:g}%): ₹{cgst:.2f}\n"
                    f"SGST ({rate/2:g}%): ₹{sgst:.2f}\n"
                )
            else:
                breakdown = f"IGST ({rate:g}%): ₹{gst:.2f}\n"

            self.gst_result.config(
                text=(
                    f"Taxable Amount: ₹{taxable:.2f}\n"
                    f"{breakdown}"
                    f"Total GST: ₹{gst:.2f}\n"
                    f"Final Amount: ₹{total:.2f}"
                )
            )

        except Exception as error:
            messagebox.showerror("GST Error", str(error))

    # ========================================================
    # THEME SYSTEM
    # ========================================================

    def apply_theme(self):
        theme = self.themes[self.theme_name.get()]

        self.root.configure(bg=theme["bg"])

        self.style.configure(
            "TNotebook",
            background=theme["bg"],
            borderwidth=0
        )
        self.style.configure(
            "TNotebook.Tab",
            background=theme["button"],
            foreground=theme["fg"],
            padding=(12, 8)
        )
        self.style.map(
            "TNotebook.Tab",
            background=[("selected", theme["accent"])],
            foreground=[("selected", theme["bg"])]
        )
        self.style.configure(
            "TCombobox",
            fieldbackground=theme["entry"],
            background=theme["button"],
            foreground=theme["fg"]
        )

        self.style.map(
            "TCombobox",
            fieldbackground=[("readonly", theme["entry"])],
            foreground=[("readonly", theme["fg"])]
        )

        def paint(widget):
            try:
                if isinstance(widget, tk.Canvas):
                    if widget is self.graph_canvas:
                        widget.configure(bg="white")
                    else:
                        widget.configure(bg=theme["panel"])
                elif isinstance(widget, tk.Entry):
                    widget.configure(
                        bg=theme["entry"],
                        fg=theme["fg"],
                        insertbackground=theme["fg"]
                    )
                elif isinstance(widget, tk.Button):
                    widget.configure(
                        bg=theme["button"],
                        fg=theme["fg"],
                        activebackground=theme["accent"],
                        activeforeground=theme["bg"],
                        relief="flat"
                    )
                elif isinstance(widget, tk.Label):
                    widget.configure(
                        bg=theme["panel"],
                        fg=theme["fg"]
                    )
                elif isinstance(widget, tk.Frame):
                    widget.configure(bg=theme["panel"])
            except tk.TclError:
                pass

            for child in widget.winfo_children():
                paint(child)

        for widget in self.root.winfo_children():
            paint(widget)

        self.heading.configure(
            bg=theme["bg"],
            fg=theme["accent"]
        )
        self.history_button.configure(
            bg=theme["button"],
            fg=theme["fg"],
            activebackground=theme["accent"]
        )


# ============================================================
# RUN APPLICATION
# ============================================================

if __name__ == "__main__":
    root = tk.Tk()
    app = AdvancedCalculator(root)
    root.mainloop()